# Overview
Historical & demonstration templates for deploying heketi in k8s.
Unless you are a heketi developer, or plan to be, you almost certainly
want to refer to [gluster-kubernetes](https://github.com/gluster/gluster-kubernetes)
which is a complete tool for deploying glusterfs and heketi into
k8s and openshift.
